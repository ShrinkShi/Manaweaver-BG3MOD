# 邪术师强化：渐进魔能爆（Patch 8） v3

## 等级表
- 1级：1束，1d10
- 2级：2束，1d10 / 1d10
- 3级：2束，1d12 / 1d10
- 4级：2束，1d12 / 1d12
- 5级：3束，1d12 / 1d12 / 1d10
- 6级：3束，d14 / d12 / d10
- 7级：3束，d14 / d14 / d10
- 8级：3束，d14 / d14 / d14
- 9级：3束，d16 / d14 / d14
- 10级：3束，d16 / d16 / d14
- 11级：3束，d16 / d16 / d14（按用户给出的 9、10、12 节点，11级保持）
- 12级：3束，d16 / d16 / d16

## d14/d16 的实现
BG3 原生骰面没有 d14/d16。本版采用原生安全等期望替代：
- d14 -> 1d12+1（平均同为7.5）
- d16 -> 1d12+2（平均同为8.5）
因此平均伤害与目标一致，但概率分布不是严格均匀的1..14/1..16。

## 实现
- Script Extender 运行时修改 EldritchBlast LevelMap：2级开始2束，5级开始3束。
- 监听 DealDamage，仅当 SpellId 为 Projectile_EldritchBlast 且基础 Damage 表达式包含 1d10 时，按角色总等级和该次施法内的伤害触发序号替换基础骰。
- 只替换 1d10 token，尽量保留 Potent Cantrip 的 /2 等外层逻辑。
- DealtDamage 后恢复原始 functor，降低对其他攻击/后续施法的污染。
- 不主动修改 Hex、苦痛魔爆、强能法袍、斥力魔爆、旧日支配者心灵伤害类型。

## 注意
当某束完全未触发 DealDamage（例如普通未命中且没有 Potent Cantrip）时，后续命中的束会依次获得本次施法剩余的高阶骰。全命中时严格对应第1/2/3束顺序。这是当前 v3 的已知边界，日志会记录每次实际分配。

## 安装
需要 BG3 Script Extender。因为沿用 v2 的相同 UUID 和 Folder，可直接用 BG3MM 导入此版覆盖旧版，然后确认 Active Mods 并 Save Load Order。

## 日志
`%LOCALAPPDATA%\Larian Studios\Baldur's Gate 3\Script Extender\Shrink_EldritchBlastProgressive_Patch8_v3\server.log`

重点测试：2、3、5、6、8、9、10、11、12级。
