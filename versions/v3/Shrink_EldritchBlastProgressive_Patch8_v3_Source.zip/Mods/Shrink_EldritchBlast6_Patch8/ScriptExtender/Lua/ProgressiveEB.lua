local M = {}

local EB_LEVELMAP_UUID = "ecad9e7a-389d-4789-ba69-898cfd34da3c"
local TARGET_BEAM_COUNTS = { 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3 }

-- Native-safe representation:
-- requested d14 -> 1d12+1 (same mean 7.5, different distribution)
-- requested d16 -> 1d12+2 (same mean 8.5, different distribution)
local DAMAGE_BY_LEVEL = {
    [1]  = { "1d10" },
    [2]  = { "1d10", "1d10" },
    [3]  = { "1d12", "1d10" },
    [4]  = { "1d12", "1d12" },
    [5]  = { "1d12", "1d12", "1d10" },
    [6]  = { "1d12+1", "1d12",   "1d10" },
    [7]  = { "1d12+1", "1d12+1", "1d10" },
    [8]  = { "1d12+1", "1d12+1", "1d12+1" },
    [9]  = { "1d12+2", "1d12+1", "1d12+1" },
    [10] = { "1d12+2", "1d12+2", "1d12+1" },
    [11] = { "1d12+2", "1d12+2", "1d12+1" },
    [12] = { "1d12+2", "1d12+2", "1d12+2" },
}

local counters = {}
local restoreStacks = {}

local function appendLog(path, line)
    local old = ""
    local ok, content = pcall(Ext.IO.LoadFile, path)
    if ok and content then old = content end
    pcall(Ext.IO.SaveFile, path, old .. line .. "\n")
end

local function log(msg)
    local line = "[Shrink Progressive EB] " .. tostring(msg)
    Ext.Utils.Print(line)
    appendLog("Shrink_EldritchBlastProgressive_Patch8_v3/server.log", line)
end

local function serializeLevelMaps(resource)
    local ok, value = pcall(function() return Ext.Types.Serialize(resource.LevelMaps) end)
    if ok then return value end
    return nil
end

local function stringify(values)
    if not values then return "<nil>" end
    local t = {}
    for i,v in ipairs(values) do t[#t+1] = tostring(i) .. "=" .. tostring(v) end
    return table.concat(t, ", ")
end

local function applyBeamCounts(reason)
    local resource = Ext.StaticData.Get(EB_LEVELMAP_UUID, "LevelMap")
    if not resource then
        log(reason .. ": ERROR LevelMap not found")
        return false
    end
    local before = serializeLevelMaps(resource)
    local ok, err = pcall(function()
        Ext.Types.Unserialize(resource.LevelMaps, TARGET_BEAM_COUNTS)
    end)
    if not ok then
        log(reason .. ": ERROR writing LevelMap: " .. tostring(err))
        return false
    end
    local after = serializeLevelMaps(resource)
    log(reason .. ": beams before: " .. stringify(before))
    log(reason .. ": beams after : " .. stringify(after))
    return true
end

local function getCasterLevel(e)
    local ok, level = pcall(function()
        if e.Caster and e.Caster.Stats then return tonumber(e.Caster.Stats.Level) end
        return nil
    end)
    if ok and level then
        if level < 1 then level = 1 end
        if level > 12 then level = 12 end
        return level
    end
    return 1
end

local function spellPrototype(e)
    local ok, value = pcall(function()
        if e.SpellId then
            if e.SpellId.Prototype and e.SpellId.Prototype ~= "" then return tostring(e.SpellId.Prototype) end
            if e.SpellId.SpellProto and e.SpellId.SpellProto.Name then return tostring(e.SpellId.SpellProto.Name) end
        end
        return ""
    end)
    return ok and value or ""
end

local function castKey(e)
    local ok, key = pcall(function()
        if e.Hit and e.Hit.SpellCastGuid then return tostring(e.Hit.SpellCastGuid) end
        return nil
    end)
    if ok and key and key ~= "" and key ~= "00000000-0000-0000-0000-000000000000" then return key end
    return tostring(e.StoryActionId or 0) .. ":" .. tostring(e.Caster)
end

local function functorKey(e)
    local ok, key = pcall(function()
        if e.Functor and e.Functor.FunctorUuid then return tostring(e.Functor.FunctorUuid) end
        return tostring(e.Functor)
    end)
    return ok and key or "unknown"
end

local function originalDamageCode(e)
    local ok, code = pcall(function() return tostring(e.Functor.Damage.Code) end)
    return ok and code or ""
end

local function pushRestore(key, code)
    local stack = restoreStacks[key]
    if not stack then stack = {}; restoreStacks[key] = stack end
    stack[#stack+1] = code
end

local function popRestore(key)
    local stack = restoreStacks[key]
    if not stack or #stack == 0 then return nil end
    local code = stack[#stack]
    stack[#stack] = nil
    if #stack == 0 then restoreStacks[key] = nil end
    return code
end

local function chooseDamage(level, index)
    local row = DAMAGE_BY_LEVEL[level] or DAMAGE_BY_LEVEL[12]
    if index < 1 then index = 1 end
    if index > #row then index = #row end
    return row[index]
end

function M.OnDealDamage(e)
    if spellPrototype(e) ~= "Projectile_EldritchBlast" then return end
    if not e.Functor or not e.Functor.Damage then return end

    local oldCode = originalDamageCode(e)
    -- Only touch Eldritch Blast's own base d10 functors. Riders such as Hex use other spells/functors.
    if not string.find(oldCode, "1d10", 1, true) then return end

    local key = castKey(e)
    local n = (counters[key] or 0) + 1
    counters[key] = n
    local level = getCasterLevel(e)
    local desired = chooseDamage(level, n)

    -- Preserve wrapper logic such as Potent Cantrip's 1d10/2 by replacing only the first 1d10 token.
    local replacement = "(" .. desired .. ")"
    local newCode, count = string.gsub(oldCode, "1d10", replacement, 1)
    if count ~= 1 then return end

    local fkey = functorKey(e)
    pushRestore(fkey, oldCode)
    local ok, err = pcall(function() e.Functor.Damage = newCode end)
    if not ok then
        popRestore(fkey)
        log("ERROR set damage: " .. tostring(err))
        return
    end

    log("cast=" .. key .. " level=" .. tostring(level) .. " beam=" .. tostring(n) ..
        " old=" .. oldCode .. " new=" .. newCode .. " damageType=" .. tostring(e.Functor.DamageType))
end

function M.OnDealtDamage(e)
    if spellPrototype(e) ~= "Projectile_EldritchBlast" then return end
    if not e.Functor or not e.Functor.Damage then return end
    local fkey = functorKey(e)
    local oldCode = popRestore(fkey)
    if oldCode then
        local ok, err = pcall(function() e.Functor.Damage = oldCode end)
        if not ok then log("ERROR restore damage: " .. tostring(err)) end
    end
end

function M.Apply(reason)
    return applyBeamCounts(reason)
end

return M
