local EB = Ext.Require("ProgressiveEB.lua")

Ext.Events.StatsLoaded:Subscribe(function()
    EB.Apply("ClientStatsLoaded")
end, { Priority = 100 })

Ext.Events.SessionLoaded:Subscribe(function()
    EB.Apply("ClientSessionLoaded")
end, { Priority = 100 })
