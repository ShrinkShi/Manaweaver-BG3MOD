local EB = Ext.Require("ProgressiveEB.lua")

Ext.Events.StatsLoaded:Subscribe(function()
    EB.Apply("StatsLoaded")
end, { Priority = 100 })

Ext.Events.SessionLoaded:Subscribe(function()
    EB.Apply("SessionLoaded")
end, { Priority = 100 })

Ext.Events.DealDamage:Subscribe(function(e)
    EB.OnDealDamage(e)
end, { Priority = 100 })

Ext.Events.DealtDamage:Subscribe(function(e)
    EB.OnDealtDamage(e)
end, { Priority = -100 })
