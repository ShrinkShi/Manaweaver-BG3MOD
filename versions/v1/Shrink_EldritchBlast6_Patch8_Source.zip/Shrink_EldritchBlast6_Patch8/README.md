# Eldritch Blast - 6 Beams (Patch 8)

功能：只修改魔能爆（Eldritch Blast）的射线数量成长。

- 角色等级 1-2：1 束
- 角色等级 3-4：2 束
- 角色等级 5-6：3 束
- 角色等级 7-8：4 束
- 角色等级 9-10：5 束
- 角色等级 11-12：6 束
- 角色等级 13-20：维持 6 束（仅用于兼容等级上限 MOD，不增加伤害）

实现：覆盖原版 LevelMapValues 中 UUID ecad9e7a-389d-4789-ba69-898cfd34da3c 的 EldritchBlast 条目。
不覆盖 Projectile_EldritchBlast 的 SpellData，因此不主动修改 Patch 8 的魔能爆伤害/伤害类型/斥力等逻辑。

安装：
1. 推荐使用 BG3 Mod Manager。
2. File -> Import Mod，选择 Shrink_EldritchBlast6_Patch8.pak。
3. 将 MOD 移到 Active Mods，保存 Load Order。
4. 如果另一个 MOD 也覆盖 EldritchBlast 的 LevelMap，同一记录会存在加载顺序冲突；把本 MOD 放在需要被它覆盖的 MOD 后面。

MOD UUID: 8255350e-db90-430a-826b-98fb79372b69
版本：1.0.0.0
