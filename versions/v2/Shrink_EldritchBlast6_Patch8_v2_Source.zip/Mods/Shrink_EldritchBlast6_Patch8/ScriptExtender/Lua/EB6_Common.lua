local EB_UUID = "ecad9e7a-389d-4789-ba69-898cfd34da3c"
local TARGET_LEVEL_MAPS = { 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6 }

local function stringifyValues(values)
    local out = {}
    for i, v in ipairs(values) do
        out[#out + 1] = tostring(i) .. "=" .. tostring(v)
    end
    return table.concat(out, ", ")
end

local function readLevelMaps(resource)
    local ok, result = pcall(function()
        return Ext.Types.Serialize(resource.LevelMaps)
    end)
    if not ok then
        return nil, tostring(result)
    end
    return result, nil
end

local function appendLog(path, line)
    local old = ""
    local ok, content = pcall(Ext.IO.LoadFile, path)
    if ok and content then
        old = content
    end
    Ext.IO.SaveFile(path, old .. line .. "\n")
end

local function makeLogger(side)
    local logPath = "Shrink_EldritchBlast6_Patch8_v2/" .. side .. ".log"
    return function(message)
        local line = "[Shrink EB6][" .. side .. "] " .. tostring(message)
        Ext.Utils.Print(line)
        appendLog(logPath, line)
    end
end

local function apply(side)
    local log = makeLogger(side)
    log("apply begin")

    local resource = Ext.StaticData.Get(EB_UUID, "LevelMap")
    if not resource then
        log("ERROR: EldritchBlast LevelMap not found: " .. EB_UUID)
        return false
    end

    log("resource found; Name=" .. tostring(resource.Name) .. "; UUID=" .. EB_UUID)

    local before, beforeErr = readLevelMaps(resource)
    if not before then
        log("ERROR reading LevelMaps before change: " .. tostring(beforeErr))
        return false
    end
    log("before: " .. stringifyValues(before))

    local ok, err = pcall(function()
        Ext.Types.Unserialize(resource.LevelMaps, TARGET_LEVEL_MAPS)
    end)
    if not ok then
        log("ERROR applying LevelMaps: " .. tostring(err))
        return false
    end

    local after, afterErr = readLevelMaps(resource)
    if not after then
        log("ERROR reading LevelMaps after change: " .. tostring(afterErr))
        return false
    end
    log("after:  " .. stringifyValues(after))

    local expected = stringifyValues(TARGET_LEVEL_MAPS)
    local actual = stringifyValues(after)
    if actual == expected then
        log("SUCCESS: runtime EldritchBlast LevelMap matches target")
        return true
    else
        log("ERROR: verification mismatch; expected " .. expected)
        return false
    end
end

return {
    Apply = apply
}
