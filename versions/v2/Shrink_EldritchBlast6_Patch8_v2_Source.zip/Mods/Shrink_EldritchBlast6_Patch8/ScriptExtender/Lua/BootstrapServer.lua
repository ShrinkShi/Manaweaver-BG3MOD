local EB6 = Ext.Require("EB6_Common.lua")

Ext.Events.StatsLoaded:Subscribe(function()
    EB6.Apply("server-statsloaded")
end, { Priority = 0 })

Ext.Events.SessionLoaded:Subscribe(function()
    EB6.Apply("server-sessionloaded")
end, { Priority = 0 })
