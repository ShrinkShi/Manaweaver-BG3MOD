# 魔能爆强化：六重射线（Patch 8） v2

## 功能
- 角色总等级 1-2：1束
- 3-4：2束
- 5-6：3束
- 7-8：4束
- 9-10：5束
- 11-12：6束
- 当前版本不修改伤害骰。

## v2 修复
v1 使用独立 LevelMapValues.lsx 静态覆盖；实测 Patch 8 环境未生效。
v2 改为 BG3 Script Extender 在 StatsLoaded / SessionLoaded 时直接覆盖运行时 EldritchBlast LevelMap。

## 依赖
需要 Norbyte BG3 Script Extender（Patch 8 兼容）。

## 安装
1. 在 BG3 Mod Manager 中安装/更新 Script Extender。
2. 导入本 MOD 的 .pak。
3. 将 MOD 移入 Active Mods 并保存 Load Order。
4. 彻底退出并重新启动游戏。

## 中文名称
BG3 Mod Manager 中显示为：`魔能爆强化：六重射线（Patch 8）`

## 自动诊断日志
进入游戏后，本 MOD 会自动生成日志：

`%LOCALAPPDATA%\Larian Studios\Baldur's Gate 3\Script Extender\Shrink_EldritchBlast6_Patch8_v2\`

其中可能包含：
- `server-statsloaded.log`
- `server-sessionloaded.log`
- `client-statsloaded.log`
- `client-sessionloaded.log`

正常情况下日志应看到：
`before: 1=1, 2=1, 3=1, 4=1, 5=2 ...`
随后：
`after: 1=1, 2=1, 3=2, 4=2, 5=3 ... 11=6, 12=6`
以及：
`SUCCESS: runtime EldritchBlast LevelMap matches target`

如果游戏内仍未生效，把这个目录中的全部 .log 上传给 ChatGPT。
